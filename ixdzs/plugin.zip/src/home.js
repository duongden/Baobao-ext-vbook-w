function execute() {
    return Response.success([
        { title: "完结作品", input: "https://ixdzs8.com/end/", script: "gen.js" },
        { title: "总榜", input: "https://ixdzs8.com/hot/", script: "gen.js" },
        { title: "月榜", input: "https://ixdzs8.com/hot/month/", script: "gen.js" },
        { title: "日榜", input: "https://ixdzs8.com/hot/day/", script: "gen.js" },
    ]);
}
