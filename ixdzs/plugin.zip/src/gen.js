function execute(url, page) {
    const host = getHost(url);
    if (page && page !== "1") url = absoluteUrl(page, host);
    const html = Http.get(absoluteUrl(url, host)).html();
    let next = null;
    let nextEl = html.select(".pagei a[title*='下一']").first();
    if (nextEl) next = nextEl.attr("href") || null;
    let el = html.select(".u-list li");
    const data = []; 
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        let cover = absoluteUrl(e.select(".l-img img").attr("src"), host);
        let name = e.select(".bname a").text();
        let author = e.select(".bauthor a").text();
        let link = absoluteUrl(e.select(".l-img a").attr("href"), host);
        data.push({
            name: name,
            link: link,
            cover: cover,
            description: author,
            host: host
        });
    }
    return Response.success(data, next);
}

function getHost(url) {
    let match = String(url || "").match(/^(https?:\/\/[^\/]+)/i);
    return match ? match[1] : "https://ixdzs8.com";
}

function absoluteUrl(href, host) {
    if (!href) return "";
    if (/^https?:\/\//i.test(href)) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    return host + (href.charAt(0) === "/" ? href : "/" + href);
}
