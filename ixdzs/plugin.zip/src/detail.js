function execute(url) {
    const host = getHost(url);
    const doc = Http.get(url).html();
    let name = doc.select(".n-text h1").text();
    let cover = absoluteUrl(doc.select(".n-img img").attr("src"), host);
    let author = doc.select(".n-text p").first().select("a").text();
    let description = doc.select("#intro").html();
    description = String(description || "")
        .replace(/<span[^>]*c-more[^>]*>[\s\S]*$/i, "")
        .replace(/\n/g, "<br>");
    let detail = `作者： ${author}<br>字数: ${doc.select(".n-text p").get(2).select("span").text()}<br>最新: ${doc.select(".n-text p").get(3).select("a").text()}<br>${doc.select(".n-text p").last().text()}`;
    let status = doc.select(".n-text p").get(1).text();
    let ongoing = /連載中|连载中/.test(status);
    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail,
        ongoing: ongoing,
        host: host,
    });
}

function getHost(url) {
    let match = String(url || "").match(/^(https?:\/\/[^\/]+)/i);
    return match ? match[1] : "https://ixdzs8.com";
}

function absoluteUrl(href, host) {
    if (!href) return "";
    if (/^https?:\/\//i.test(href)) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    return host + (href.charAt(0) === "/" ? href : "/" + href);
}
