function execute(url) {
    let headers = {};
    let challengeSessionId = "";
    if (/^https?:\/\/(?:www\.)?ixdzs8\.com\//i.test(String(url || ""))) {
        challengeSessionId = getChallengeSessionId();
        headers.Cookie = "PHPSESSID=" + challengeSessionId;
    }

    let response = fetch(url, { headers: headers });
    if (!response.ok) return Response.error("Không tải được chương");

    let doc = response.html();
    let challenge = String(doc.html() || "").match(/let\s+token\s*=\s*[\"']([^\"']+)[\"']/i);
    if (challenge) {
        let challengeUrl = String(url).split("?")[0] + "?challenge=" + encodeURIComponent(challenge[1]);
        response = fetch(challengeUrl, { headers: headers });
        if (!response.ok) return Response.error("Không vượt được bước xác minh của trang nguồn");
        doc = response.html();
    }

    let el = doc.select('.page-content p');
    if (el.size() === 0) {
        return Response.error("Không tìm thấy nội dung. Hãy mở Trang nguồn một lần để hoàn tất xác minh.");
    }
    if (challengeSessionId) saveChallengeSessionId(challengeSessionId);
    let chapter_info = el.get(0).text().trim();
    for (var i= 1; i < el.size(); i++) {
        var e = el.get(i);
        chapter_info = chapter_info + '<br>' + e.text().trim();
    }
    return Response.success(chapter_info);
}

function getChallengeSessionId() {
    const cacheKey = "ixdzs8.challenge.session.v2";
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && typeof cacheStorage.getItem === "function") {
            let cached = String(cacheStorage.getItem(cacheKey) || "");
            if (/^[a-z0-9]{26}$/i.test(cached)) return cached;
        }
    } catch (e0) {}

    let seed = "vb" + new Date().getTime().toString(36);
    while (seed.length < 26) seed += Math.random().toString(36).substring(2);
    return seed.substring(0, 26);
}

function saveChallengeSessionId(sessionId) {
    try {
        if (typeof cacheStorage !== "undefined" && cacheStorage && typeof cacheStorage.setItem === "function") {
            cacheStorage.setItem("ixdzs8.challenge.session.v2", sessionId);
        }
    } catch (e) {}
}
