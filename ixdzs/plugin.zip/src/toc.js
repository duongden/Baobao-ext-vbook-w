function execute(url) {
    const matched = String(url || "").match(/read\/(\d+)/);
    if (!matched) return Response.error("Không tìm thấy ID truyện");

    const novelId = matched[1];
    const host = getHost(url);
    const body = "bid=" + novelId;
    var response = fetch(host + "/novel/clist/", {
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        },
        body: body,
    });
    if (response.ok) {
        var payload = null;
        try {
            payload = response.json();
        } catch (e) {
            // Domain cũ có thể chưa dùng API JSON; thử endpoint HTML bên dưới.
        }
        if (payload && String(payload.rs) === "200" && payload.data) {
            var jsonList = [];
            for (var i = 0; i < payload.data.length; i++) {
                var chapter = payload.data[i];
                if (String(chapter.ctype) === "1") continue;
                jsonList.push({
                    name: String(chapter.title || ""),
                    url: host + "/read/" + novelId + "/p" + String(chapter.ordernum || "") + ".html",
                    host: host
                });
            }
            return Response.success(jsonList);
        }
    }

    response = fetch(host + "/novel/html/", {
        method: "POST",
        headers: {
            "content-type": "application/x-www-form-urlencoded"
        },
        body: body,
    });
    if (response.ok) {
        const html = response.html();
        const htmlList = [];
        const el = html.select("li a");
        for (var j = 0; j < el.size(); j++) {
            var a = el.get(j);
            htmlList.push({
                name: a.text(),
                url: absoluteUrl(a.attr("href"), host),
                host: host
            });
        }
        return Response.success(htmlList);
    }

    return Response.error("Không tải được mục lục");
}

function getHost(url) {
    let match = String(url || "").match(/^(https?:\/\/[^\/]+)/i);
    return match ? match[1] : "https://ixdzs8.com";
}

function absoluteUrl(href, host) {
    if (!href) return "";
    if (/^https?:\/\//i.test(href)) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    return host + (href.charAt(0) === "/" ? href : "/" + href);
}
