function execute(key, page) {
    const host = "https://ixdzs8.com";
    let url;
    if (!page || page === "1") {
        url = host + "/bsearch?q=" + encodeURIComponent(key);
    } else {
        url = absoluteUrl(page, host);
    }
    const html = Http.get(url).html();
    let next = null;
    let nextEl = html.select(".pagei a[title*='下一']").first();
    if (nextEl) next = nextEl.attr("href") || null;
    const data = []; 
    let el = html.select(".u-list li");
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        let cover = absoluteUrl(e.select(".l-img img").attr("src"), host);
        let name = e.select(".bname a").text();
        let author = e.select(".bauthor a").text();
        let link = absoluteUrl(e.select(".l-img a").attr("href"), host);
        data.push({
            name: name,
            link: link,
            cover: cover,
            description: author,
            host: host
        });
    }
    return Response.success(data, next);
}

function absoluteUrl(href, host) {
    if (!href) return "";
    if (/^https?:\/\//i.test(href)) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    return host + (href.charAt(0) === "/" ? href : "/" + href);
}
