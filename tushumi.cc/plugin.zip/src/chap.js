function execute(url) {
    url = desktopChapterUrl(url);
    const doc = Http.get(url).html();
    let el = doc.select('#content p');
    if (el.size() === 0) return Response.error("Không tìm thấy nội dung chương");
    let chapter_info = el.get(0).text().trim();
    for (var i= 1; i < el.size(); i++) {
        var e = el.get(i);
        chapter_info = chapter_info + '<br>' + e.text().trim();
    }
    return Response.success(chapter_info);
}

function desktopChapterUrl(url) {
    return String(url || "").replace(/^https?:\/\/(?:www\.|m\.)?tushumi\.cc/i, "https://www.tushumi.cc");
}
